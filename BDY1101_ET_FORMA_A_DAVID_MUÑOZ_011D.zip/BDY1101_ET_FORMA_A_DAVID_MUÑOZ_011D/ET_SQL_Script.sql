/* Limpiar Tablas */

DROP TABLE contratoProfesor CASCADE CONSTRAINTS;
DROP TABLE escuela CASCADE CONSTRAINTS;
DROP TABLE recinto CASCADE CONSTRAINTS;
DROP TABLE municipalidad CASCADE CONSTRAINTS;
DROP TABLE tipoContrato CASCADE CONSTRAINTS;
DROP TABLE profesor CASCADE CONSTRAINTS;
DROP TABLE director CASCADE CONSTRAINTS;
DROP TABLE deporte CASCADE CONSTRAINTS;
DROP TABLE detalleInversion CASCADE CONSTRAINTS;

/* Crear tablas */

CREATE TABLE deporte (
idDeporte NUMBER(10) NOT NULL,
nomDeporte VARCHAR2(15) NOT NULL,
CONSTRAINT pkDeporte PRIMARY KEY (idDeporte));

CREATE TABLE director (
rutDirector VARCHAR2(15) NOT NULL,
nombre VARCHAR2(15) NOT NULL,
apellido VARCHAR2(15) NOT NULL,
direccion VARCHAR2(30),
comuna VARCHAR2(20) NOT NULL,
region VARCHAR2(20) NOT NULL,
telefono VARCHAR2(15) NOT NULL,
correo VARCHAR2(30) NOT NULL,
profesion VARCHAR2(30) NOT NULL,
nacionalidad VARCHAR2(20) NOT NULL,
estadoCivil VARCHAR2(20),
CONSTRAINT pkDirector PRIMARY KEY (rutDirector));

CREATE TABLE profesor (
rutProfesor VARCHAR2(15) NOT NULL,
nombre VARCHAR2(15) NOT NULL,
especialidad VARCHAR2(30),
universidad VARCHAR2(30),
direProf VARCHAR2(30) NOT NULL,
afp VARCHAR2(20),
isapre VARCHAR2(20),
sueldoBase VARCHAR2(15),
valorHora VARCHAR2(15),
horasMensuales VARCHAR2(15),
CONSTRAINT pkProfesor PRIMARY KEY (rutProfesor));

CREATE TABLE tipoContrato (
idTC NUMBER(10) NOT NULL,
tipoCon VARCHAR2(10) NOT NULL,
CONSTRAINT pkTipoContra PRIMARY KEY (idTC));

CREATE TABLE municipalidad (
idMuni NUMBER(10) NOT NULL,
nomMuni VARCHAR2(30) NOT NULL,
direccion VARCHAR2(30) NOT NULL,
CONSTRAINT pkMuni PRIMARY KEY (idMuni));

CREATE TABLE recinto (
idRecinto NUMBER(10) NOT NULL,
nomRecinto VARCHAR2(50) NOT NULL,
dirRec VARCHAR2(50),
capacidad VARCHAR2(15),
idMuni NUMBER(10) NOT NULL,
CONSTRAINT pkRecinto PRIMARY KEY (idRecinto),
CONSTRAINT fkRecintoMuni FOREIGN KEY (idMuni)
REFERENCES municipalidad (idMuni));

CREATE TABLE detalleInversion (
idInversion NUMBER(10) NOT NULL,
montoSolicitado VARCHAR(150) NOT NULL,
nombreProyecto VARCHAR(50),
tipoInversion VARCHAR(30) NOT NULL,
CONSTRAINT pkDetalle PRIMARY KEY (idInversion));

CREATE TABLE escuela (
idEscuela NUMBER(10) NOT NULL,
nomEscuela VARCHAR2(50) NOT NULL,
comuna VARCHAR2(20) NOT NULL,
region VARCHAR2(20) NOT NULL,
nomCD VARCHAR2(30),
sitioWeb VARCHAR2(50),
fechaResolusion VARCHAR2(15) NOT NULL,
presupuestoAnual VARCHAR2(15) NOT NULL,
idRecinto NUMBER(10) NOT NULL,
CONSTRAINT pkEscuela PRIMARY KEY (idEscuela));

CREATE TABLE contratoProfesor (
idContrato NUMBER(10) NOT NULL,
idEscuela NUMBER(10) NOT NULL,
idProfesor VARCHAR2(15) NOT NULL,
idTipoContrato NUMBER(10) NOT NULL,
CONSTRAINT pkContratoProfesor PRIMARY KEY (idContrato),
CONSTRAINT fkCpEscuela FOREIGN KEY (idEscuela) REFERENCES escuela(idEscuela),
CONSTRAINT fkCpProfesor FOREIGN KEY (idProfesor) REFERENCES profesor(rutProfesor),
CONSTRAINT fkCpTipo FOREIGN KEY (idTipoContrato) REFERENCES tipoContrato(idTC));

/* Insertar datos */

INSERT INTO deporte VALUES (1, 'Futbol');
INSERT INTO deporte VALUES (2, 'Basketball');

INSERT INTO director VALUES ('17.324.835-2', 'Jorge', 'Valdivia', 'Av. El salvador 425', 'San Bernardo', 'Metropolitana', '+56982638940',
'jorgevaldivia@gmail.com', 'Administrador de Empresas', 'Chileno', 'Soltero');
INSERT INTO director VALUES ('12.946.253-k', 'Selena', 'Gomez', 'Calle Los Platanos 099', 'Futrono', 'Los Lagos', '+56902759927',
'selenagomez@gmail.com', 'Gestor de Bienes Raices', 'Chilena', 'Casada');

INSERT INTO profesor VALUES ('11.347.682-3', 'Gonzalo Fierro', 'Preparador Fisico', 'IP. Santo Tomas', 'Psj. El Roble 692', 'Capital',
'No Afiliado', '$650.000', '$4.062', '160');
INSERT INTO profesor VALUES ('13.849.502-1', 'Megan Fox', 'Kinesiologia', 'DuocUC', 'Av. Santa Luisa 074', 'Modelo', 'Banmedica',
'$600.000', '$4.000', '160');

INSERT INTO tipoContrato VALUES (1, 'Indefinido');
INSERT INTO tipoContrato VALUES (2, 'Honorarios');

INSERT INTO municipalidad VALUES (1, 'Municipalidad de Macul', 'Av. Quilin 3248');
INSERT INTO municipalidad VALUES (2, 'Municipalidad de Quilicura', 'Jose Francisco Vergara 450');

INSERT INTO recinto VALUES (1, 'Estadio Monumental David Arellano', 'Av. Marathon 5300', '43000', 1);
INSERT INTO recinto VALUES (2, 'Gimnasio Municipal', 'Av. Santa Luisa 007', '200', 1);

INSERT INTO detalleInversion VALUES (1, '$7.000.000', 'Sistema de Regadio', 'Implementos');
INSERT INTO detalleInversion VALUES (2, '$2.350.000', 'Mejoras en las gradas', 'Infraestructura');

INSERT INTO escuela VALUES (1, 'Escuela de Futbol Alexis Sanchez', 'Quilicura', 'Metropolitana', 'Escuela Alexis Sanchez',
'escuelaalexis.cl', '27/03/2026', 15000000, 1);
INSERT INTO escuela VALUES (2, 'Academia de Basket Kobe Bryant', 'Cerro Navia', 'Metropolitana', 'Academia Kobe Bryant',
'kobeacademy.com', '15/05/2026', 8000000, 2);

INSERT INTO contratoProfesor VALUES (1, 1, '11.347.682-3', 1);
INSERT INTO contratoProfesor VALUES (2, 2, '13.849.502-1', 2);
INSERT INTO contratoProfesor VALUES (3, 1, '11.347.682-3', 2);


COMMIT;

/* Ver tablas */

SELECT * FROM municipalidad;

SELECT * FROM recinto;

SELECT * FROM escuela;

SELECT * FROM director;

SELECT * FROM profesor;

SELECT * FROM contratoProfesor;

SELECT * FROM tipoContrato;

SELECT * FROM deporte;

SELECT * FROM detalleinversion;



